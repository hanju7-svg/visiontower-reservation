비전타워 예약 앱 시연용 배포 파일

GitHub에서 새 public repository를 만들고 index.html 파일을 업로드하세요.
Settings > Pages > Deploy from a branch > main > /(root) > Save
접속주소: https://사용자명.github.io/저장소명/

주의: 기기별 localStorage 저장만 지원. 실제 다중 사용자 예약/실제 QR 인증 미구현. 공식 교시시간과 강의실 정원 미검증.
